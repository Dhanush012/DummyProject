package com.example.User_Input.Repository;

import com.example.User_Input.Entity.Inputs;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InputsRepo extends JpaRepository<Inputs,Long> {
}
