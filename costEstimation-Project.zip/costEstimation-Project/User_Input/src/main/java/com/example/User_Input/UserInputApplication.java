package com.example.User_Input;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserInputApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserInputApplication.class, args);
	}

}
