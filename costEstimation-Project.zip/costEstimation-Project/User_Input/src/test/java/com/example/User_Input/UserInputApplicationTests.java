package com.example.User_Input;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserInputApplicationTests {

	@Test
	void contextLoads() {
	}

}
