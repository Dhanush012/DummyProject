package com.ConstructionCalculator.CostEstimator.Service;


// import java.util.List;
// import java.util.Optional;

// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.stereotype.Service;

// import com.ConstructionCalculator.CostEstimator.Model.CostEstimate;
// import com.ConstructionCalculator.CostEstimator.Repository.CostEstimateRepository;


// @Service
// public class CostEstimateService {

//     @Autowired
//     private CostEstimateRepository costEstimateRepository;

//     // Create a new cost estimate
//     public CostEstimate createCostEstimate(CostEstimate costEstimate) {
//         costEstimate.setGeneratedAt(java.time.LocalDateTime.now()); // Ensure timestamp is set
//         return costEstimateRepository.save(costEstimate);
//     }

//     // Get all cost estimates
//     public List<CostEstimate> getAllCostEstimates() {
//         return costEstimateRepository.findAll();
//     }

//     // Get cost estimate by ID
//     public Optional<CostEstimate> getCostEstimateById(Long id) {
//         return costEstimateRepository.findById(id);
//     }

//     // Update a cost estimate
//     public Optional<CostEstimate> updateCostEstimate(Long id, CostEstimate updatedCostEstimate) {
//         return costEstimateRepository.findById(id).map(existingCostEstimate -> {
//             existingCostEstimate.setProjectId(updatedCostEstimate.getProjectId());
//             existingCostEstimate.setConstructorId(updatedCostEstimate.getConstructorId());
//             existingCostEstimate.setTotalEstimate(updatedCostEstimate.getTotalEstimate());
//             return costEstimateRepository.save(existingCostEstimate);
//         });
//     }

//     // Delete a cost estimate
//     public boolean deleteCostEstimate(Long id) {
//         if (costEstimateRepository.existsById(id)) {
//             costEstimateRepository.deleteById(id);
//             return true;
//         }
//         return false;
//     }
// }


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.ConstructionCalculator.CostEstimator.Model.CostEstimate;
import com.ConstructionCalculator.CostEstimator.Repository.CostEstimateRepository;

@Service
public class CostEstimateService {

    @Autowired
    private CostEstimateRepository costEstimateRepository;

    @Autowired
    private WebClient.Builder webClientBuilder;

    public CostEstimate calculateCost(Long inputId) {
        // Fetch input data from Inputs service
        Double builtupArea = webClientBuilder.build()
                .get()
                .uri("http://localhost:8081/api/inputs/" + inputId)
                .retrieve()
                .bodyToMono(Double.class)
                .block();

        if (builtupArea == null) {
            throw new RuntimeException("Failed to fetch built-up area from Inputs Service");
        }

        // Calculate cost
        double costPerSqFt = 1500; // Example cost per square foot
        double totalCost = builtupArea * costPerSqFt;

        // Save estimate
        CostEstimate estimate = new CostEstimate();
        estimate.setInputId(inputId);
        estimate.setBuiltupArea(builtupArea);
        estimate.setTotalCost(totalCost);
        return costEstimateRepository.save(estimate);
    }

    public List<CostEstimate> getAllEstimates() {
        return costEstimateRepository.findAll();
    }
}
