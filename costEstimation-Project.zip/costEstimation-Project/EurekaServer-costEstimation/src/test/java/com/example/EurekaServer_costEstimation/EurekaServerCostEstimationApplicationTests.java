package com.example.EurekaServer_costEstimation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaServerCostEstimationApplicationTests {

	@Test
	void contextLoads() {
	}

}
