package com.ConstructionCalculator.CostEstimator.Controller;

// import java.util.HashMap;
// import java.util.List;
// import java.util.Map;
// import java.util.Optional;

// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.http.ResponseEntity;
// import org.springframework.web.bind.annotation.DeleteMapping;
// import org.springframework.web.bind.annotation.GetMapping;
// import org.springframework.web.bind.annotation.PathVariable;
// import org.springframework.web.bind.annotation.PostMapping;
// import org.springframework.web.bind.annotation.PutMapping;
// import org.springframework.web.bind.annotation.RequestBody;
// import org.springframework.web.bind.annotation.RequestMapping;
// import org.springframework.web.bind.annotation.RestController;

// import com.ConstructionCalculator.CostEstimator.Model.CostEstimate;
// import com.ConstructionCalculator.CostEstimator.Service.CostEstimateService;

// @RestController
// @RequestMapping("/api/cost-estimates")
// public class CostEstimateController {

//     @Autowired
//     private CostEstimateService costEstimateService;

//     // Create a new cost estimate
//     @PostMapping
//     public ResponseEntity<CostEstimate> createCostEstimate(@RequestBody CostEstimate costEstimate) {
//         return ResponseEntity.status(201).body(costEstimateService.createCostEstimate(costEstimate));
//     }

//     // Get all cost estimates
//     @GetMapping
//     public ResponseEntity<List<CostEstimate>> getAllCostEstimates() {
//         return ResponseEntity.ok(costEstimateService.getAllCostEstimates());
//     }

//     // Get cost estimate by ID
//     @GetMapping("/{id}")
//     public ResponseEntity<CostEstimate> getCostEstimateById(@PathVariable Long id) {
//         Optional<CostEstimate> estimate = costEstimateService.getCostEstimateById(id);
//         return estimate.map(ResponseEntity::ok).orElse(ResponseEntity.status(404).body(null));
//     }

//     // Update cost estimate
//     @PutMapping("/{id}")
//     public ResponseEntity<CostEstimate> updateCostEstimate(@PathVariable Long id, @RequestBody CostEstimate updatedCostEstimate) {
//         Optional<CostEstimate> estimate = costEstimateService.updateCostEstimate(id, updatedCostEstimate);
//         return estimate.map(ResponseEntity::ok).orElse(ResponseEntity.status(404).body(null));
//     }

//     // Delete cost estimate
//     @DeleteMapping("/{id}")
//     public ResponseEntity<Void> deleteCostEstimate(@PathVariable Long id) {
//         if (costEstimateService.deleteCostEstimate(id)) {
//             return ResponseEntity.noContent().build();
//         }
//         return ResponseEntity.status(404).build();
//     }

//     // Calculate total cost estimate
//     @GetMapping("/calculate/{area}/{type}")
//     public ResponseEntity<Object> calculateTotalCostEstimate(@PathVariable double area, @PathVariable int type) {
//         try {
//             if (type != 1 && type != 2) {
//                 return ResponseEntity.badRequest().body("Type must be 1 or 2");
//             }
//             double costPerUnit = type == 1 ? 1202 : 1560;
//             double totalCostEstimate = area * costPerUnit;
//             return ResponseEntity.ok(totalCostEstimate);
//         } catch (Exception e) {
//             return ResponseEntity.status(500).body("Failed to calculate total cost estimate");
//         }
//     }

//     // Quantity-wise calculation
//     @GetMapping("/quantity/{cost}/{area}")
//     public ResponseEntity<Map<String, Object>> quantityWiseCalculation(@PathVariable double cost, @PathVariable double area) {
//         try {
//             Map<String, Object> quantities = new HashMap<>();
//             quantities.put("cementReq", Math.ceil(area * 0.4));
//             quantities.put("cementCost", 16.4 / 100 * cost);

//             quantities.put("sandReq", Math.round(area * 0.816 * 100.0) / 100.0);
//             quantities.put("sandCost", 12.3 / 100 * cost);

//             quantities.put("aggregateReq", Math.round(area * 0.608 * 100.0) / 100.0);
//             quantities.put("aggregateCost", 7.4 / 100 * cost);

//             quantities.put("steelReq", Math.ceil(area * 4));
//             quantities.put("steelCost", 24.6 / 100 * cost);

//             quantities.put("paintReq", Math.round(area * 0.18 * 100.0) / 100.0);
//             quantities.put("bricks", Math.ceil(area * 8));

//             quantities.put("fittings", 22.8 / 100 * cost);
//             quantities.put("finishers", 16.5 / 100 * cost);

//             return ResponseEntity.ok(quantities);
//         } catch (Exception e) {
//             return ResponseEntity.status(500).build();
//         }
//     }
// }



import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ConstructionCalculator.CostEstimator.Model.CostEstimate;
import com.ConstructionCalculator.CostEstimator.Service.CostEstimateService;

@RestController
@RequestMapping("/api/cost-estimates")
public class CostEstimateController {

    @Autowired
    private CostEstimateService costEstimateService;

    @PostMapping("/{inputId}")
    public ResponseEntity<CostEstimate> calculateCost(@PathVariable Long inputId) {
        CostEstimate estimate = costEstimateService.calculateCost(inputId);
        return ResponseEntity.ok(estimate);
    }

    @GetMapping("/calculate/{inputId}")
    public ResponseEntity<Object> getCostEstimate(@PathVariable Long inputId) {
        Optional<CostEstimate> costEstimateOpt = costEstimateService.getCostEstimate(inputId);
        if (costEstimateOpt.isPresent()) {
            return ResponseEntity.ok(costEstimateOpt.get());
        } else {
            return ResponseEntity.status(404).body("Input not found");
        }
    }

    
    @GetMapping
    public ResponseEntity<List<CostEstimate>> getAllEstimates() {
        return ResponseEntity.ok(costEstimateService.getAllEstimates());
    }
}
